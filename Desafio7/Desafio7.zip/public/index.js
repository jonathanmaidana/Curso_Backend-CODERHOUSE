const server = io().connect();

// server.on('message', data => {
//     console.log('message', data);
// })

function render(messages){
    const html = messages.map(function (e,i) {
        return(`<div>
        <strong>${e.author}</strong>
        <em>${e.text}</em>
        </div>`)
    }).join(" ");

    document.getElementById('messages').innerHTML = html;
}

server.on('message', (messages) => {
    render(messages)
});


function addMessage(e) {
    const mensaje = {
        author: document.getElementById('username').value,
        text: document.getElementById('texto').value
    };
    server.emit('new-message', mensaje);
    return false;
}